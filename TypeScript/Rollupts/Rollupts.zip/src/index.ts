const a:string = 'ikun'
console.log(a)