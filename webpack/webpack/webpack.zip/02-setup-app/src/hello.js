function hello() {
  console.log('hello webpack')
}
export default hello