import hello from "./hello";
hello()