import _ from 'lodash'
console.log(_.join(['another', 'module', 'load'], ' '))