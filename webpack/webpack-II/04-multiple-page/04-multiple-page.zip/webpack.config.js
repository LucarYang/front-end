const path = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')
module.exports = {
  mode: 'development',
  plugins: [
    new HtmlWebpackPlugin({
      title: '多页面应用',
      template: './index.html',
      inject: 'body',
      filename: 'chanel1/index.html',
      chunks: ['main', 'lodash'],
      publicPath: 'http://www.b.com/'
    }),
    new HtmlWebpackPlugin({
      template: './index2.html',
      inject: 'body',
      filename: 'chanel2/index2.html',
      chunks: ['main2', 'lodash'],
      publicPath: 'http://www.a.com/'
    })
  ],
  // entry: ['./src/app.js', './src/app2.js', 'lodash']
  entry: {
    // main: ['./src/app.js', './src/app2.js'],
    main: {
      import: ['./src/app.js', './src/app2.js'],
      dependOn: 'lodash',
    },
    main2: {
      import: './src/app3.js',
      dependOn: 'lodash',
    },
    lodash: 'lodash'
  },
  output: {
    clean: true
  }
}