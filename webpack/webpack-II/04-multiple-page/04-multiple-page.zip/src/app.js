import _ from "lodash";
console.log(0);
console.log(_.join(["hello", 'entry'], ' '))
